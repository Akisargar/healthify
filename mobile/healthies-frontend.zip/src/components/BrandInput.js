import React from "react";
import { TextInput, StyleSheet } from "react-native";
import colors from "../theme/colors";

export default function BrandInput({ placeholder, value, onChangeText }) {
  return (
    <TextInput
      placeholder={placeholder}
      placeholderTextColor="#8BAAA2"
      value={value}
      onChangeText={onChangeText}
      style={styles.input}
    />
  );
}

const styles = StyleSheet.create({
  input: {
    backgroundColor: colors.white,
    borderColor: colors.secondary,
    borderWidth: 1.5,
    padding: 12,
    borderRadius: 10,
    marginVertical: 10,
    color: colors.text,
    fontSize: 16,
  },
});
