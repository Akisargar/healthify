import React from "react";
import { View, Text, StyleSheet } from "react-native";
import colors from "../theme/colors";

export default function BrandCard({ children, type = "normal" }) {
  return (
    <View style={[styles.card, type === "alert" && styles.alert]}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    padding: 16,
    borderRadius: 12,
    marginVertical: 10,
    borderColor: colors.secondary,
    borderWidth: 1.2,
  },
  alert: {
    borderColor: colors.accent,
    backgroundColor: "#FFF6E9",
  },
});
