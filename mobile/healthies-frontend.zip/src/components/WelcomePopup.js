import React from "react";
import { Modal, View, Text, StyleSheet, TouchableOpacity } from "react-native";
import colors from "../theme/colors";

export default function WelcomePopup({ visible, onClose, onViewReport }) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.card}>
          <Text style={styles.title}>🌞 Good Morning!</Text>
          <Text style={styles.text}>
            Welcome back! Check your yesterday’s health report.
          </Text>

          <TouchableOpacity style={styles.btn} onPress={onViewReport}>
            <Text style={styles.btnText}>View Yesterday Report</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={onClose}>
            <Text style={styles.skip}>Maybe later</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>  
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    width: "85%",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
  },
  title: { fontSize: 20, fontWeight: "800", marginBottom: 8 },
  text: {
    textAlign: "center",
    color: colors.text,
    marginBottom: 16,
  },
  btn: {
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  btnText: { color: "#fff", fontWeight: "700" },
  skip: {
    marginTop: 12,
    color: colors.text,
    opacity: 0.7,
  },
});
