import React, { useEffect, useState, createContext } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { ActivityIndicator, View, Text } from "react-native";

import AuthFlowScreen from "../screens/AuthFlowScreen";
import OnboardingScreen from "../screens/OnboardingScreen";
import TabNavigator from "./TabNavigator";
import api, { loadToken } from "../utils/api";

const Stack = createNativeStackNavigator();

// ✅ Auth context
export const AuthContext = createContext({ refresh: async () => {} });

export default function AppNavigator() {
  const [loading, setLoading] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  const refresh = async () => {
    try {
      const token = await loadToken();

      if (!token) {
        setLoggedIn(false);
        setNeedsOnboarding(false);
        return;
      }

      setLoggedIn(true);

      const res = await api.get("/user/me");
      const user = res.data?.user;

      if (!user?.disease) {
        setNeedsOnboarding(true);
      } else {
        setNeedsOnboarding(false);
      }
    } catch (e) {
      console.log("Auth refresh error:", e);
      setLoggedIn(false);
      setNeedsOnboarding(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  // ⏳ Loading screen
  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" />
        <Text>Loading app...</Text>
      </View>
    );
  }

  return (
    <AuthContext.Provider value={{ refresh }}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {!loggedIn ? (
          <Stack.Screen name="Auth" component={AuthFlowScreen} />
        ) : needsOnboarding ? (
          <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        ) : (
          <Stack.Screen name="MainTabs" component={TabNavigator} />
        )}
      </Stack.Navigator>
    </AuthContext.Provider>
  );
}
