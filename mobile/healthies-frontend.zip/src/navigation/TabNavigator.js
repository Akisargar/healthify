import React, { useEffect, useState } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Text } from "react-native";

import FoodCheckScreen from "../screens/FoodCheckScreen";
import ProfileScreen from "../screens/ProfileScreen";
import ReportsStack from "./ReportsStack";
import colors from "../theme/colors";
import WelcomePopup from "../components/WelcomePopup";

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 7 && hour < 11) {
      setShowPopup(true);
    }
  }, []);

  return (
    <>
      {/* 🌞 Welcome Popup */}
      <WelcomePopup
        visible={showPopup}
        onClose={() => setShowPopup(false)}
        onViewReport={() => {
          setShowPopup(false);
          // ✅ Navigate via tab route name
          // ReportsStack will handle the inner screen
        }}
      />

      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: "#999",
          tabBarStyle: {
            backgroundColor: "#fff",
            height: 60,
            paddingBottom: 6,
          },
        }}
      >
        {/* 🥗 Scan */}
        <Tab.Screen
          name="Scan"
          component={FoodCheckScreen}
          options={{
            tabBarLabel: ({ color }) => (
              <Text style={{ color, fontSize: 13 }}>Scan</Text>
            ),
          }}
        />

        {/* 📊 Reports stack */}
        <Tab.Screen
          name="Reports"
          component={ReportsStack}
          options={{
            tabBarLabel: ({ color }) => (
              <Text style={{ color, fontSize: 13 }}>Reports</Text>
            ),
          }}
        />

        {/* 👤 Profile */}
        <Tab.Screen
          name="Profile"
          component={ProfileScreen}
          options={{
            tabBarLabel: ({ color }) => (
              <Text style={{ color, fontSize: 13 }}>Profile</Text>
            ),
          }}
        />
      </Tab.Navigator>
    </>
  );
}
