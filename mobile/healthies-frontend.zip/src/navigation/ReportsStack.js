import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import TodayReportScreen from "../screens/TodayReportScreen";
import YesterdayReportScreen from "../screens/YesterdayReportScreen";
import MonthlyReportScreen from "../screens/MonthlyReportScreen";

const Stack = createNativeStackNavigator();

export default function ReportsStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="TodayReport"
        component={TodayReportScreen}
        options={{ title: "Today" }}
      />
      <Stack.Screen
        name="YesterdayReport"
        component={YesterdayReportScreen}
        options={{ title: "Yesterday" }}
      />
      <Stack.Screen
        name="MonthlyReport"
        component={MonthlyReportScreen}
        options={{ title: "Monthly" }}
      />
    </Stack.Navigator>
  );
}
  