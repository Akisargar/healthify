export default {
    primary: '#3BAF7C',
    secondary: '#6FD8C1',
    accent: '#FFB86C',
    background: '#F6FFFB',
    text: '#1E3D35',
  
    white: '#FFFFFF',
    dark: '#1E3D35',
  };
  