import axios from "axios";
import * as SecureStore from "expo-secure-store";

const API_BASE = "http://192.168.0.116:4000";

const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

// ---------------- SET TOKEN ----------------
export async function setToken(token) {
  try {
    if (token) {
      await SecureStore.setItemAsync("token", token);
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
      console.log("✅ Token saved");
    } else {
      await SecureStore.deleteItemAsync("token");
      delete api.defaults.headers.common["Authorization"];
      console.log("🗑️ Token cleared");
    }
  } catch (e) {
    console.log("❌ setToken error:", e);
  }
}

// ---------------- LOAD TOKEN ----------------
export async function loadToken() {
  try {
    console.log("🔄 Loading token...");
    const token = await SecureStore.getItemAsync("token");
    console.log("🔑 Loaded token:", token);

    if (token) {
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    }

    return token;
  } catch (e) {
    console.log("❌ loadToken error:", e);
    return null; // never block app
  }
}

// ---------------- CLEAR TOKEN ----------------
export async function clearToken() {
  try {
    await SecureStore.deleteItemAsync("token");
    delete api.defaults.headers.common["Authorization"];
    console.log("🗑️ Token deleted");
  } catch (e) {
    console.log("❌ clearToken error:", e);
  }
}

export default api;
