import React, { useState, useEffect, useRef, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import api, { setToken } from "../utils/api";
import BrandButton from "../components/BrandButton";
import BrandInput from "../components/BrandInput";
import colors from "../theme/colors";
import { AuthContext } from "../navigation/AppNavigator";

export default function OTPScreen({ route, navigation }) {
  const { phone } = route.params || {};
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [resendTimer, setResendTimer] = useState(0);
  const timerRef = useRef(null);

  const { refresh } = useContext(AuthContext);

  useEffect(() => {
    startResendCountdown(60);
    return () => clearInterval(timerRef.current);
  }, []);

  const startResendCountdown = (seconds) => {
    setResendTimer(seconds);
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const verify = async () => {
    if (!phone) {
      setErrorMsg("Phone number missing. Please go back.");
      return;
    }
    if (!code.trim()) {
      setErrorMsg("Please enter the OTP.");
      return;
    }

    setLoading(true);
    setErrorMsg("");

    try {
      const res = await api.post("/auth/verify-otp", { phone, code });
      const { token } = res.data || {};

      if (!token) {
        setErrorMsg("Invalid OTP. Please try again.");
        return;
      }

      // ✅ Save token
      await setToken(token);

      // ✅ Refresh auth state → AppNavigator switches to MainTabs
      await refresh();
    } catch (err) {
      const serverMsg =
        err.response?.data?.error ||
        err.response?.data?.message ||
        "OTP verification failed";
      setErrorMsg(serverMsg);
    } finally {
      setLoading(false);
    }
  };

  const resendOtp = async () => {
    if (!phone) return;

    try {
      setLoading(true);
      const res = await api.post("/auth/send-otp", { phone });

      if (res?.data?.devCode) {
        alert(`OTP resent (dev): ${res.data.devCode}`);
      } else {
        alert("OTP resent successfully");
      }

      startResendCountdown(60);
    } catch (err) {
      setErrorMsg("Could not resend OTP");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={styles.card}>
        <Text style={styles.heading}>Verify your phone</Text>
        <Text style={styles.subtext}>We sent an OTP to</Text>
        <Text style={styles.phone}>{phone}</Text>

        <BrandInput
          placeholder="Enter 6-digit OTP"
          value={code}
          onChangeText={(v) => {
            setCode(v);
            if (errorMsg) setErrorMsg("");
          }}
          keyboardType="number-pad"
        />

        {errorMsg ? <Text style={styles.errorText}>{errorMsg}</Text> : null}

        <BrandButton
          title={loading ? "Verifying..." : "Verify & Continue"}
          onPress={verify}
          disabled={loading}
        />

        <View style={styles.row}>
          {loading && <ActivityIndicator color={colors.primary} />}
          <TouchableOpacity
            onPress={resendOtp}
            disabled={resendTimer > 0 || loading}
          >
            <Text style={styles.resendText}>
              {resendTimer > 0 ? `Resend in ${resendTimer}s` : "Resend OTP"}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.back}
        >
          <Text style={styles.backText}>Change number</Text>
        </TouchableOpacity>

        <Text style={styles.disclaimer}>
          AI suggestions are informational only and not medical advice.
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: "center",
    padding: 20,
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: 20,
    elevation: 4,
  },
  heading: {
    fontSize: 20,
    fontWeight: "700",
    textAlign: "center",
    color: colors.text,
  },
  subtext: {
    textAlign: "center",
    color: colors.text,
    opacity: 0.7,
    marginTop: 6,
  },
  phone: {
    textAlign: "center",
    color: colors.primary,
    fontWeight: "700",
    marginBottom: 14,
  },
  row: {
    marginTop: 10,
    alignItems: "center",
  },
  resendText: {
    color: colors.primary,
    fontWeight: "600",
    marginTop: 6,
  },
  back: {
    marginTop: 14,
    alignItems: "center",
  },
  backText: {
    color: colors.text,
    opacity: 0.8,
  },
  disclaimer: {
    marginTop: 16,
    fontSize: 12,
    color: colors.text,
    opacity: 0.6,
    textAlign: "center",
  },
  errorText: {
    color: "red",
    marginBottom: 8,
    textAlign: "center",
  },
});
