import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import api from "../utils/api";
import colors from "../theme/colors";

export default function MonthlyReportScreen() {
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");
  const [month, setMonth] = useState(getCurrentMonth());

  useEffect(() => {
    fetchReport(month);
  }, [month]);

  function getCurrentMonth() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  }


  const fetchReport = async (m) => {
    try {
      setLoading(true);
      setError("");
      setReport(null);

      const res = await api.post("/reports/monthly/ai", { month: m });
      setReport(res.data);
    } catch (err) {
      console.log("Monthly report error:", err?.response?.data || err.message);
      setError("Could not generate monthly report");
    } finally {
      setLoading(false);
    }
  };

  const changeMonth = (offset) => {
    const [y, m] = month.split("-").map(Number);
    const date = new Date(y, m - 1 + offset, 1);
    const newMonth = `${date.getFullYear()}-${String(
      date.getMonth() + 1
    ).padStart(2, "0")}`;
    setMonth(newMonth);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 10 }}>Generating monthly report...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={{ color: "red" }}>{error}</Text>
        <TouchableOpacity onPress={() => fetchReport(month)}>
          <Text style={{ color: colors.primary, marginTop: 10 }}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!report) {
    return (
      <View style={styles.center}>
        <Text>No report available</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Month selector */}
      <View style={styles.monthRow}>
        <TouchableOpacity onPress={() => changeMonth(-1)}>
          <Text style={styles.monthBtn}>◀</Text>
        </TouchableOpacity>
        <Text style={styles.monthText}>{month}</Text>
        <TouchableOpacity onPress={() => changeMonth(1)}>
          <Text style={styles.monthBtn}>▶</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.title}>Monthly Health Report</Text>

      <Text style={styles.sectionTitle}>Summary</Text>
      <Text style={styles.text}>{report.summary}</Text>

      {report.goodFoods?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Good Foods</Text>
          {report.goodFoods.map((f, i) => (
            <Text key={i} style={styles.text}>• {f.item}</Text>
          ))}
        </>
      )}

      {report.problemFoods?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Problem Foods</Text>
          {report.problemFoods.map((f, i) => (
            <Text key={i} style={styles.text}>• {f.item}</Text>
          ))}
        </>
      )}

      {report.patterns && (
        <>
          <Text style={styles.sectionTitle}>Patterns</Text>
          <Text style={styles.text}>{report.patterns}</Text>
        </>
      )}

      {report.recommendations?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Recommendations</Text>
          {report.recommendations.map((r, i) => (
            <Text key={i} style={styles.text}>• {r}</Text>
          ))}
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: colors.background,
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  monthRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  monthBtn: {
    fontSize: 20,
    color: colors.primary,
    paddingHorizontal: 12,
  },
  monthText: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
  },
  title: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    marginBottom: 16,
    textAlign: "center",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginTop: 14,
    marginBottom: 6,
    color: colors.primary,
  },
  text: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
});
