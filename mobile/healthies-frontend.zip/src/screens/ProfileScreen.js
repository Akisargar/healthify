import React, { useEffect, useState, useContext } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import api, { clearToken } from "../utils/api";
import colors from "../theme/colors";
import { AuthContext } from "../navigation/AppNavigator";

export default function ProfileScreen() {
  const [user, setUser] = useState(null);
  const { refresh } = useContext(AuthContext);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const res = await api.get("/user/me");
      setUser(res.data.user);
    } catch (err) {
      console.log("Profile load error:", err?.response?.data || err.message);
    }
  };

  const logout = async () => {
    try {
      // ✅ Clear token
      await clearToken();

      // ✅ Refresh auth → AppNavigator switches to Login
      await refresh();
    } catch (e) {
      console.log("Logout error:", e);  
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Profile</Text>

      {user && (
        <>
          <Text style={styles.item}>📱 Phone: {user.phone}</Text>
          <Text style={styles.item}> Name: {user.username}</Text>
          <Text style={styles.item}>🦠 Disease: {user.disease}</Text>
        </>
      )}
      <TouchableOpacity onPress={logout} style={styles.logoutBtn}>
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: "700", marginBottom: 20 },
  item: { fontSize: 16, marginBottom: 10 },
  logoutBtn: {
    marginTop: 30,
    backgroundColor: "#ff5252",
    padding: 14,
    borderRadius: 10,
  },
  logoutText: { color: "#fff", textAlign: "center", fontWeight: "700" },
});
