import React, { useEffect, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  Platform,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';

import api from '../utils/api';
import colors from '../theme/colors';
import { AuthContext } from '../navigation/AppNavigator';

// If you already have BrandButton / BrandCard, these imports will override the local fallbacks.
// Otherwise the fallback components defined below will be used.
let BrandButton;
let BrandCard;
try {
  BrandButton = require('../components/BrandButton').default;
  BrandCard = require('../components/BrandCard').default;
} catch (e) {
  // fallback simple components so the screen still works
  BrandButton = ({ title, onPress, disabled }) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      style={[
        styles.fallbackButton,
        disabled ? { opacity: 0.6 } : null,
      ]}
    >
      <Text style={styles.fallbackButtonText}>{title}</Text>
    </TouchableOpacity>
  );

  BrandCard = ({ children }) => (
    <View style={styles.card}>
      {children}
    </View>
  );
}

export default function OnboardingScreen() {
  const { refresh } = useContext(AuthContext);

  const [disease, setDisease] = useState('Ulcerative Colitis');
  const [diseases, setDiseases] = useState(['Ulcerative Colitis']);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const res = await api.get('/meta/diseases'); // optional endpoint
        if (!mounted) return;

        if (
          res?.data?.diseases &&
          Array.isArray(res.data.diseases) &&
          res.data.diseases.length
        ) {
          setDiseases(res.data.diseases);
          setDisease(res.data.diseases[0]);
        }
      } catch (err) {
        // optional endpoint — safe to ignore
        console.debug(
          'No remote diseases list (ok):',
          err?.message || err
        );
      }
    })();

    return () => {
      mounted = false;
    };
  }, []);

  const submit = async () => {
    setErrorMsg('');

    if (!disease || disease.trim().length === 0) {
      setErrorMsg('Please select a disease to continue.');
      return;
    }

    setLoading(true);
    try {
      await api.put('/user/me', { disease });

      // ✅ Let AppNavigator handle the transition
      await refresh();
    } catch (err) {
      console.error(
        'Onboarding save error',
        err.response?.data || err.message || err
      );

      const serverMsg =
        err.response?.data?.error ||
        err.response?.data?.message;

      setErrorMsg(
        serverMsg || 'Error saving profile. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const renderPicker = () => {
    if (Platform.OS === 'ios') {
      return (
        <View style={styles.iosPickerWrap}>
          <Picker
            selectedValue={disease}
            onValueChange={(v) => {
              setDisease(v);
              if (errorMsg) setErrorMsg('');
            }}
            style={styles.picker}
            itemStyle={{ color: colors.text }}
          >
            {diseases.map((d) => (
              <Picker.Item key={d} label={d} value={d} />
            ))}
          </Picker>
        </View>
      );
    }

    return (
      <View style={styles.androidPickerWrap}>
        <Picker
          selectedValue={disease}
          onValueChange={(v) => {
            setDisease(v);
            if (errorMsg) setErrorMsg('');
          }}
          style={styles.picker}
        >
          {diseases.map((d) => (
            <Picker.Item key={d} label={d} value={d} />
          ))}
        </Picker>
      </View>
    );
  };

  return (
    <View style={styles.screen}>
      <Text style={styles.header}>Tell us about your health</Text>
      <Text style={styles.subheader}>
        This helps Healthies provide personalised food checks and
        suggestions.
      </Text>

      <BrandCard>
        <Text style={styles.label}>What is your disease?</Text>

        {renderPicker()}

        {errorMsg ? (
          <Text style={styles.errorText}>{errorMsg}</Text>
        ) : null}

        <Text style={styles.disclaimer}>
          Healthies provides informational guidance only. It is not a
          medical service. For urgent or severe symptoms, consult a
          physician.
        </Text>

        <View style={{ marginTop: 8 }}>
          {loading ? (
            <ActivityIndicator />
          ) : (
            <BrandButton
              title="Continue"
              onPress={submit}
            />
          )}
        </View>
      </BrandCard>

      <View style={styles.bottomInfo}>
        <Text style={styles.smallText}>
          You can change this later in profile settings.
        </Text>

        <TouchableOpacity
          onPress={() => {
            Alert.alert(
              'Privacy & Disclaimer',
              'Healthies stores minimal profile data locally. AI suggestions are informational only.'
            );
          }}
          style={styles.privacyLink}
        >
          <Text style={styles.privacyText}>
            Privacy & disclaimer
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 20,
  },
  header: {
    fontSize: 24,
    color: colors.text,
    fontWeight: '800',
    marginTop: 18,
    marginBottom: 6,
  },
  subheader: {
    fontSize: 14,
    color: colors.text,
    opacity: 0.75,
    marginBottom: 18,
  },
  card: {
    backgroundColor: colors.white,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.secondary,
    elevation: 3,
  },
  label: {
    color: colors.text,
    fontWeight: '700',
    marginBottom: 8,
    fontSize: 16,
  },
  iosPickerWrap: {
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 1.2,
    borderColor: colors.secondary,
    backgroundColor: colors.background,
    marginBottom: 10,
  },
  androidPickerWrap: {
    borderRadius: 10,
    borderWidth: 1.2,
    borderColor: colors.secondary,
    backgroundColor: colors.white,
    marginBottom: 10,
  },
  picker: {
    height: 48,
    width: '100%',
    color: colors.text,
  },
  errorText: {
    color: colors.accent,
    marginTop: 6,
    fontSize: 13,
  },
  disclaimer: {
    marginTop: 8,
    color: colors.text,
    opacity: 0.7,
    fontSize: 13,
  },
  bottomInfo: {
    marginTop: 22,
    alignItems: 'center',
  },
  smallText: {
    color: colors.text,
    opacity: 0.6,
    fontSize: 13,
  },
  privacyLink: {
    marginTop: 8,
  },
  privacyText: {
    color: colors.primary,
    fontWeight: '700',
  },

  // fallback button
  fallbackButton: {
    backgroundColor: colors.primary,
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  fallbackButtonText: {
    color: colors.white,
    fontWeight: '700',
    fontSize: 16,
  },
});
