import React, { useState, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import api, { setToken } from "../utils/api";
import colors from "../theme/colors";
import { AuthContext } from "../navigation/AppNavigator";

export default function AuthFlowScreen() {
  const [step, setStep] = useState("phone"); 
  // phone | otp | creds

  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const { refresh } = useContext(AuthContext);

  // 📩 Send OTP
  const sendOtp = async () => {
    if (!phone.trim()) return setError("Enter phone number");

    try {
      setLoading(true);
      setError("");

      const res = await api.post("/auth/send-otp", { phone: phone.trim() });

      if (res.data?.devCode) {
        alert(`Dev OTP: ${res.data.devCode}`);
      }

      setStep("otp");
    } catch {
      setError("Failed to send OTP");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Verify OTP
  const verifyOtp = async () => {
    if (!code.trim()) return setError("Enter OTP");

    try {
      setLoading(true);
      setError("");

      await api.post("/auth/verify-otp", {
        phone: phone.trim(),
        code: code.trim(),
      });

      // 👉 After OTP verified → ask for username/password
      setStep("creds");
    } catch {
      setError("Invalid OTP");
    } finally {
      setLoading(false);
    }
  };

  // 🔐 Login with username & password
  const loginWithCreds = async () => {
    if (!username.trim()) return setError("Enter username");
    if (!password.trim()) return setError("Enter password");

    try {
      setLoading(true);
      setError("");

      const res = await api.post("/auth/login", {
        phone: phone.trim(),
        username: username.trim(),
        password,
      });

      const { token } = res.data || {};
      if (!token) throw new Error("No token");

      await setToken(token);
      await refresh(); // ✅ AppNavigator switches to MainTabs
    } catch {
      setError("Login failed. Check username/password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={styles.card}>
        <Text style={styles.title}>Welcome to Healthies</Text>

        {/* 📱 PHONE STEP */}
        {step === "phone" && (
          <>
            <TextInput
              placeholder="Enter mobile number"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              style={styles.input}
            />
            <TouchableOpacity style={styles.btn} onPress={sendOtp} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Send OTP</Text>}
            </TouchableOpacity>
          </>
        )}

        {/* 🔢 OTP STEP */}
        {step === "otp" && (
          <>
            <Text style={styles.info}>OTP sent to {phone}</Text>
            <TextInput
              placeholder="Enter OTP"
              value={code}
              onChangeText={setCode}
              keyboardType="number-pad"
              style={styles.input}
            />
            <TouchableOpacity style={styles.btn} onPress={verifyOtp} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Verify OTP</Text>}
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setStep("phone")}>
              <Text style={styles.link}>Change number</Text>
            </TouchableOpacity>
          </>
        )}

        {/* 👤 USERNAME / PASSWORD STEP */}
        {step === "creds" && (
          <>
            <Text style={styles.info}>Welcome back! Login to continue</Text>

            <TextInput
              placeholder="Username"
              value={username}
              onChangeText={setUsername}
              style={styles.input}
            />

            <TextInput
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              style={styles.input}
            />

            <TouchableOpacity style={styles.btn} onPress={loginWithCreds} disabled={loading}>
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Login</Text>}
            </TouchableOpacity>
          </>
        )}

        {error ? <Text style={styles.error}>{error}</Text> : null}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20, backgroundColor: colors.background },
  card: { backgroundColor: "#fff", borderRadius: 16, padding: 22 },
  title: { fontSize: 22, fontWeight: "800", textAlign: "center", marginBottom: 16 },
  info: { textAlign: "center", marginBottom: 10, color: colors.text },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 10, padding: 12, marginBottom: 10 },
  btn: { backgroundColor: colors.primary, padding: 14, borderRadius: 10, alignItems: "center", marginTop: 6 },
  btnText: { color: "#fff", fontWeight: "700" },
  link: { marginTop: 10, textAlign: "center", color: colors.primary, fontWeight: "600" },
  error: { color: "red", textAlign: "center", marginTop: 10 },
});
