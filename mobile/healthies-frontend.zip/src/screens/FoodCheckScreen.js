import React, { useRef, useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  ActivityIndicator,
  Alert,
  Platform,
  ScrollView,
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import colors from "../theme/colors";
import api, { loadToken } from "../utils/api";
import * as ImageManipulator from "expo-image-manipulator";

export default function FoodCheckScreen() {
  const cameraRef = useRef(null);

  const [permission, requestPermission] = useCameraPermissions();
  const [captured, setCaptured] = useState(null);
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState(null);
  const [logging, setLogging] = useState(false);

  useEffect(() => {
    loadToken();
  }, []);

  /* ---------- CAMERA ACTION ---------- */
  const takePicture = async () => {
    try {
      if (!cameraRef.current) return;
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.1,
        skipProcessing: true,
      });
      setCaptured(photo);
    } catch (err) {
      console.log("Camera error:", err);
    }
  };

  /* ---------- SEND IMAGE TO AI ---------- */
  const sendToAI = async () => {
    if (!captured?.uri) return;

    setSending(true);
    try {
      const resized = await ImageManipulator.manipulateAsync(
        captured.uri,
        [{ resize: { width: 512 } }],
        { compress: 0.5, format: ImageManipulator.SaveFormat.JPEG }
      );

      const formData = new FormData();
      formData.append("image", {
        uri:
          Platform.OS === "android"
            ? resized.uri
            : resized.uri.replace("file://", ""),
        name: "food.jpg",
        type: "image/jpeg",
      });

      const res = await api.post("/food/check", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setResult(res.data);
    } catch (err) {
      console.log("AI error:", err.response?.data || err.message);
      Alert.alert("Error", "Could not analyze food");
    } finally {
      setSending(false);
    }
  };

  /* ---------- LOG MEAL ---------- */
  const logMeal = async () => {
    if (!result?.food) return;

    try {
      setLogging(true);
      await api.post("/meals/log", {
        foodName: result.food,
        recommended: result.verdict === "Yes",
      });
      Alert.alert("Saved", "Meal logged successfully");
      resetScanner();
    } catch (err) {
      console.log("Log meal error:", err.response?.data || err.message);
      Alert.alert("Error", "Could not log meal");
    } finally {
      setLogging(false);
    }
  };

  const resetScanner = () => {
    setCaptured(null);
    setResult(null);
  };

  /* ---------- PERMISSION UI ---------- */
  if (!permission) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.permissionText}>
          Camera permission is required to scan food
        </Text>
        <TouchableOpacity onPress={requestPermission} style={styles.sendButton}>
          <Text style={styles.sendText}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  /* ---------- RESULT SCREEN ---------- */
  if (result) {
    return (
      <ScrollView contentContainerStyle={styles.resultContainer}>
        <Text style={styles.resultTitle}>Food Scan Result</Text>

        <Image source={{ uri: captured.uri }} style={styles.resultImage} />

        <Text style={styles.resultVerdict}>
          {result.verdict === "Yes"
            ? "✅ You can eat this"
            : "❌ Avoid this food"}
        </Text>

        <Text style={styles.resultExplanation}>{result.explanation}</Text>

        {result.alternatives?.length > 0 && (
          <View style={{ marginTop: 12 }}>
            <Text style={styles.altTitle}>Safer Alternatives</Text>
            {result.alternatives.map((a, i) => (
              <Text key={i} style={styles.altItem}>• {a}</Text>
            ))}
          </View>
        )}

        {/* 🔥 NEW: LOG MEAL BUTTON */}
        <TouchableOpacity
          onPress={logMeal}
          style={styles.logButton}
          disabled={logging}
        >
          {logging ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.scanAgainText}>I ate this</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          onPress={resetScanner}
          style={styles.scanAgainButton}
        >
          <Text style={styles.scanAgainText}>Scan Another Food</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  /* ---------- PREVIEW SCREEN ---------- */
  if (captured) {
    return (
      <View style={styles.previewContainer}>
        <Image source={{ uri: captured.uri }} style={styles.previewImage} />

        <View style={styles.actionRow}>
          <TouchableOpacity
            onPress={resetScanner}
            style={styles.retakeButton}
          >
            <Text style={styles.retakeText}>Retake</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={sendToAI}
            style={styles.sendButton}
            disabled={sending}
          >
            {sending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.sendText}>Analyze Food</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  /* ---------- CAMERA SCREEN ---------- */
  return (
    <View style={styles.container}>
      <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing="back" />

      <View style={styles.overlay}>
        <TouchableOpacity onPress={takePicture} style={styles.captureButton}>
          <View style={styles.captureInner} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* ---------- STYLES ---------- */

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  permissionText: { color: colors.text, fontSize: 16, marginBottom: 12 },

  overlay: {
    position: "absolute",
    bottom: 40,
    width: "100%",
    alignItems: "center",
  },

  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 4,
    borderColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.2)",
  },

  captureInner: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: colors.primary,
  },

  previewContainer: { flex: 1, backgroundColor: colors.background },
  previewImage: { width: "100%", height: "80%" },

  actionRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 20,
  },

  retakeButton: {
    padding: 12,
    borderRadius: 10,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: colors.secondary,
  },

  retakeText: { color: colors.text, fontWeight: "700" },

  sendButton: {
    padding: 14,
    borderRadius: 10,
    backgroundColor: colors.primary,
  },

  sendText: { color: "#fff", fontWeight: "700" },

  resultContainer: {
    padding: 20,
    alignItems: "center",
  },

  resultTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    marginBottom: 12,
  },

  resultImage: {
    width: "100%",
    height: 250,
    borderRadius: 12,
    marginBottom: 18,
  },

  resultVerdict: {
    fontSize: 20,
    fontWeight: "700",
    marginBottom: 8,
    color: colors.text,
  },

  resultExplanation: {
    fontSize: 15,
    color: colors.text,
    textAlign: "center",
  },

  altTitle: { fontWeight: "700", fontSize: 16, marginTop: 10 },
  altItem: { fontSize: 14, color: colors.text },

  logButton: {
    marginTop: 16,
    backgroundColor: "#4caf50",
    padding: 14,
    borderRadius: 10,
    width: "100%",
    alignItems: "center",
  },

  scanAgainButton: {
    marginTop: 12,
    backgroundColor: colors.primary,
    padding: 14,
    borderRadius: 10,
    width: "100%",
    alignItems: "center",
  },

  scanAgainText: { color: "#fff", fontWeight: "700" },
});
