import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import api from "../utils/api";
import colors from "../theme/colors";

export default function UserDetailsScreen() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const validate = () => {
    if (!name.trim() || name.trim().length < 2) {
      return "Please enter your full name";
    }
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
      return "Please enter a valid email address";
    }
    if (age) {
      const a = Number(age);
      if (isNaN(a) || a < 10 || a > 120) {
        return "Age must be between 10 and 120";
      }
    }
    return "";
  };

  const submit = async () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    setError("");

    try {
      // ✅ Token already saved earlier (OTP screen)
      // Axios will send Authorization header automatically
      await api.put("/user/me", {
        name: name.trim(),
        email: email.trim(),
        age: age ? Number(age) : null,
        gender,
      });

      // ✅ Nothing else here.
      // AppNavigator will auto switch to MainTabs
    } catch (err) {
      console.error("Save details error:", err?.response?.data || err.message);
      setError("Could not save details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={styles.card}>
        <Text style={styles.title}>Tell us about you</Text>

        <TextInput
          placeholder="Full Name *"
          value={name}
          onChangeText={setName}
          style={styles.input}
        />

        <TextInput
          placeholder="Email (optional)"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          style={styles.input}
        />

        <TextInput
          placeholder="Age (optional)"
          value={age}
          onChangeText={setAge}
          keyboardType="numeric"
          style={styles.input}
        />

        <View style={styles.genderRow}>
          {["Male", "Female", "Other"].map((g) => (
            <TouchableOpacity
              key={g}
              style={[
                styles.genderChip,
                gender === g && styles.genderSelected,
              ]}
              onPress={() => setGender(g)}
            >
              <Text
                style={[
                  styles.genderText,
                  gender === g && styles.genderTextSelected,
                ]}
              >
                {g}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <TouchableOpacity
          style={styles.button}
          onPress={submit}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Continue</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20 },
  card: { backgroundColor: "#fff", borderRadius: 16, padding: 22 },
  title: { fontSize: 20, fontWeight: "700", textAlign: "center", marginBottom: 12 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
  },
  genderRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 10 },
  genderChip: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 20,
    paddingVertical: 8,
    marginHorizontal: 4,
    alignItems: "center",
  },
  genderSelected: { backgroundColor: colors.primary },
  genderText: { color: "#333" },
  genderTextSelected: { color: "#fff" },
  error: { color: "red", textAlign: "center", marginBottom: 10 },
  button: {
    backgroundColor: colors.primary,
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonText: { color: "#fff", fontWeight: "700" },
});
