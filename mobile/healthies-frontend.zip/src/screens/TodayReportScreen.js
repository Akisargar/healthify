import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import api from "../utils/api";
import colors from "../theme/colors";

export default function TodayReportScreen() {
  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");

  const navigation = useNavigation();

  useEffect(() => {
    fetchReport();
  }, []);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const res = await api.post("/reports/today/ai");
      setReport(res.data);
    } catch (err) {
      console.log("Today report error:", err?.response?.data || err.message);
      setError("Could not generate today's report");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 10 }}>Generating today’s report...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={{ color: "red" }}>{error}</Text>
      </View>
    );
  }

  if (!report || !report.summary) {
    return (
      <View style={styles.center}>
        <Text>No meals logged today.</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Today’s Health Report</Text>

      <Text style={styles.sectionTitle}>Summary</Text>
      <Text style={styles.text}>{report.summary}</Text>

      {report.problemFoods?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Problem Foods</Text>
          {report.problemFoods.map((f, i) => (
            <Text key={i} style={styles.text}>• {f}</Text>
          ))}
        </>
      )}

      {report.symptomInsight && (
        <>
          <Text style={styles.sectionTitle}>Symptom Insight</Text>
          <Text style={styles.text}>{report.symptomInsight}</Text>
        </>
      )}

      {report.recommendations?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Recommendations</Text>
          {report.recommendations.map((r, i) => (
            <Text key={i} style={styles.text}>• {r}</Text>
          ))}
        </>
      )}

      {/* 🔁 NAVIGATION */}
      <View style={styles.row}>
        <TouchableOpacity
          style={styles.linkBtn}
          onPress={() => navigation.navigate("YesterdayReport")}
        >
          <Text style={styles.linkText}>← Yesterday</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.linkBtn}
          onPress={() => navigation.navigate("MonthlyReport")}
        >
          <Text style={styles.linkText}>Monthly →</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: colors.background },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    marginBottom: 16,
    textAlign: "center",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginTop: 14,
    marginBottom: 6,
    color: colors.primary,
  },
  text: { fontSize: 14, color: colors.text, lineHeight: 20 },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 24,
  },
  linkBtn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  linkText: { color: colors.primary, fontWeight: "700" },
});
