import React, { useState } from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import BrandButton from "../components/BrandButton";
import BrandInput from "../components/BrandInput";
import colors from "../theme/colors";
import api from "../utils/api";

export default function AuthScreen({ navigation }) {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const sendOtp = async () => {
    if (!phone.trim()) {
      Alert.alert("Error", "Enter phone number");
      return;
    }

    try {
      setLoading(true);

      const res = await api.post("/auth/send-otp", { phone: phone.trim() });

      if (res.data?.devCode) {
        Alert.alert("Dev OTP", res.data.devCode);
      }

      // ✅ Go to OTP screen
      navigation.navigate("OTP", { phone: phone.trim() });
    } catch (err) {
      console.log("Send OTP error:", err?.response?.data || err.message);
      Alert.alert("Error", "Failed to send OTP. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to Healthies</Text>
      <Text style={styles.subtitle}>Enter your phone number</Text>

      <BrandInput
        placeholder="+91XXXXXXXXXX"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
      />

      <BrandButton
        title={loading ? "Sending..." : "Send OTP"}
        onPress={sendOtp}
        disabled={loading}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 24,
    fontWeight: "800",
    color: colors.text,
    textAlign: "center",
    marginBottom: 6,
  },
  subtitle: {
    textAlign: "center",
    color: colors.text,
    opacity: 0.7,
    marginBottom: 20,
  },
});
