import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity, Alert, } from "react-native";
import { useNavigation } from "@react-navigation/native";
import api from "../utils/api";
import colors from "../theme/colors";

export default function YesterdayReportScreen() {
  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState(null);
  const [error, setError] = useState("");

  const [gutLoading, setGutLoading] = useState(false);
  const [gutAdvice, setGutAdvice] = useState("");

  const navigation = useNavigation();

  useEffect(() => {
    fetchReport();
  }, []);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const res = await api.post("/reports/yesterday/ai");
      setReport(res.data);
    } catch (err) {
      console.log("Report error:", err?.response?.data || err.message);
      setError("Could not generate yesterday's report");
    } finally {
      setLoading(false);
    }
  };

  const submitGut = async (status) => {
    try {
      setGutLoading(true);
      setGutAdvice("");

      // 1️⃣ Save gut feedback
      await api.post("/gut/feedback", { status });

      // 2️⃣ Get AI follow-up advice
      const res = await api.post("/reports/yesterday/followup", { status });

      setGutAdvice(res.data.message || "Thanks for your feedback!");
    } catch (err) {
      console.log("Gut feedback error:", err?.response?.data || err.message);
      Alert.alert("Error", "Could not submit gut feedback");
    } finally {
      setGutLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 10 }}>Generating AI report...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={{ color: "red" }}>{error}</Text>
      </View>
    );
  }

  if (!report || !report.summary) {
    return (
      <View style={styles.center}>
        <Text>No meals were logged yesterday.</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Yesterday’s Health Report</Text>

      <Text style={styles.sectionTitle}>Summary</Text>
      <Text style={styles.text}>{report.summary}</Text>

      {report.problemFoods?.length > 0 && (
        <>report
          <Text style={styles.sectionTitle}>Problem Foods</Text>
          {report.problemFoods.map((f, i) => (
            <Text key={i} style={styles.text}>• {f}</Text>
          ))}
        </>
      )}

      {report.symptomInsight && (
        <>
          <Text style={styles.sectionTitle}>Symptom Insight</Text>
          <Text style={styles.text}>{report.symptomInsight}</Text>
        </>
      )}

      {report.recommendations?.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Recommendations</Text>
          {report.recommendations.map((r, i) => (
            <Text key={i} style={styles.text}>• {r}</Text>
          ))}
        </>
      )}

      {/* 🩺 GUT QUESTION */}
      <Text style={styles.gutQuestion}>How is your gut today?</Text>

      <View style={styles.gutRow}>
        <TouchableOpacity
          style={[styles.gutBtn, { backgroundColor: "#4caf50" }]}
          onPress={() => submitGut("good")}
          disabled={gutLoading}
        >
          <Text style={styles.gutText}>😊 Good</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.gutBtn, { backgroundColor: "#f44336" }]}
          onPress={() => submitGut("bad")}
          disabled={gutLoading}
        >
          <Text style={styles.gutText}>😣 Bad</Text>
        </TouchableOpacity>
      </View>

      {gutLoading && (
        <ActivityIndicator style={{ marginTop: 10 }} color={colors.primary} />
      )}

      {gutAdvice ? (
        <>
          <Text style={styles.sectionTitle}>AI Advice</Text>
          <Text style={styles.text}>{gutAdvice}</Text>
        </>
      ) : null}

      {/* 🔀 NAVIGATION */}
      <TouchableOpacity
        style={styles.monthBtn}
        onPress={() => navigation.navigate("MonthlyReport")}
      >
        <Text style={styles.monthBtnText}>View Monthly Report →</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.monthBtn, { marginTop: 10 }]}
        onPress={() => navigation.navigate("TodayReport")}
      >
        <Text style={styles.monthBtnText}>← Back to Today</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: colors.background },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  title: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    marginBottom: 16,
    textAlign: "center",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginTop: 14,
    marginBottom: 6,
    color: colors.primary,
  },
  text: { fontSize: 14, color: colors.text, lineHeight: 20 },

  gutQuestion: {
    marginTop: 20,
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
    color: colors.text,
  },
  gutRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: 12,
  },
  gutBtn: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
  },
  gutText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },

  monthBtn: {
    marginTop: 24,
    alignSelf: "center",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  monthBtnText: {
    color: colors.primary,
    fontWeight: "700",
    fontSize: 14,
  },
});
